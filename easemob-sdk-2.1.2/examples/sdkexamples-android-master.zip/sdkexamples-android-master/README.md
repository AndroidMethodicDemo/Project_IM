# EaseMob SDK Examples Android ##



## ChatDemoNonUI ##
本demo展示了怎样使用环信SDK快速创建一个简单的没有UI的聊天APP。展示的功能包括：环信SDK初始化，登录，登出，注册消息接收listener, 发送文字消息

## ChatDemo ##
本demo展示了怎样使用环信SDK快速创建一个完整的类微信的聊天APP。展示的功能包括：注册新用户，用户登录，添加好友，单聊，群聊，发送文字，表情，语音，图片，地理位置。

## 快速入门（五分钟运行环信demo) ##
更多详情见：
[ http://developer.easemob.com/docs/emchat/android/quickstart.html](http://developer.easemob.com/docs/emchat/android/quickstart.html)